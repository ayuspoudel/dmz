# -------------------------------
# Docker / Compose Aliases
# -------------------------------
alias dcu='docker compose up -d'
alias dcd='docker compose down'
alias dcl='docker compose logs -f'
alias dps='docker ps'
