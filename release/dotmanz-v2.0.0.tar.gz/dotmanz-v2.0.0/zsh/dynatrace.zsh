# -------------------------------
# Dynatrace Configuration
# -------------------------------
# Safe default
export DYNATRACE_ENV_URL='https://your-default-env.dynatrace.com/api'

# Add this to private.zsh:
# export DYNATRACE_API_TOKEN='your-token-here'
