# -------------------------------
# Custom PATHs
# -------------------------------
export PATH="$HOME/Code/bin:$PATH"
